/*
==================================================
CIVIC HORIZON INDEX V2
NATIONAL PULSE CONTROLLER
==================================================
*/

import {
    subscribeToPresidentialApprovalSummary,
    submitPresidentialApprovalResponse,
    markPresidentialApprovalSubmitted,
    getPresidentialApprovalParticipationStatus
} from "../services/pulse-service.js";


/*
==================================================
RESULT ELEMENT MAP
==================================================
*/

const resultElements = {

    "Strongly Approve": {
        percentId: "stronglyApprovePercent",
        barId: "stronglyApproveBar"
    },

    "Approve": {
        percentId: "approvePercent",
        barId: "approveBar"
    },

    "Neutral": {
        percentId: "neutralPercent",
        barId: "neutralBar"
    },

    "Disapprove": {
        percentId: "disapprovePercent",
        barId: "disapproveBar"
    },

    "Strongly Disapprove": {
        percentId: "stronglyDisapprovePercent",
        barId: "stronglyDisapproveBar"
    }

};


/*
==================================================
CONTROLLER STATE
==================================================
*/

let nationalPulseControllerInitialized =
    false;


let unsubscribePulseSummary =
    null;


/*
==================================================
PUBLIC INITIALIZATION
==================================================
*/

export function initializeNationalPulseController() {

    if (
        nationalPulseControllerInitialized
    ) {

        return;

    }


    nationalPulseControllerInitialized =
        true;


    initializeApprovalForm();

    subscribeToApprovalData();

}


/*
==================================================
LIVE RESULTS
==================================================
*/

function subscribeToApprovalData() {

    unsubscribePulseSummary =
        subscribeToPresidentialApprovalSummary(

            summary => {

                renderApprovalResults(
                    summary
                );

            },

            error => {

                console.error(
                    "National Pulse data error:",
                    error
                );


                renderApprovalError();

            }

        );

}


/*
==================================================
RENDER APPROVAL RESULTS
==================================================
*/

function renderApprovalResults(
    summary
) {

    const totalResponses =
        Number(
            summary?.totalResponses
        ) || 0;


    const results =
        Array.isArray(
            summary?.results
        )
            ? summary.results
            : [];


    setText(
        "pulseResponseCount",
        formatNumber(
            totalResponses
        )
    );


    results.forEach(
        result => {

            const elementMap =
                resultElements[
                    result.response
                ];


            if (
                !elementMap
            ) {

                return;

            }


            const percentage =
                Number(
                    result.percentage
                ) || 0;


            setText(
                elementMap.percentId,
                `${percentage.toFixed(1)}%`
            );


            setBarWidth(
                elementMap.barId,
                percentage
            );

        }
    );


    const updatedAt =
        summary?.updatedAt
            ? new Date(
                summary.updatedAt
            )
            : new Date();


    setText(
        "pulseUpdatedText",
        `Updated ${formatTime(updatedAt)}`
    );

}


/*
==================================================
FORM INITIALIZATION
==================================================
*/

async function initializeApprovalForm() {

    const form =
        document.getElementById(
            "presidentialApprovalForm"
        );


    if (
        !form
    ) {

        return;

    }


    form.addEventListener(
        "submit",
        handleApprovalSubmit
    );


    try {

        const weeklyStatus =
            await getPresidentialApprovalParticipationStatus();


        if (
            weeklyStatus?.alreadyParticipated
        ) {

            lockApprovalForm(
                `You have already responded for ${weeklyStatus.votingPeriodLabel}. Voting reopens next Monday.`
            );

        }

    } catch (error) {

        console.error(
            "Presidential approval weekly status check failed:",
            error
        );

    }

}


/*
==================================================
FORM SUBMISSION
==================================================
*/

async function handleApprovalSubmit(
    event
) {

    event.preventDefault();


    const form =
        event.currentTarget;


    const selectedInput =
        form.querySelector(
            'input[name="presidentialApproval"]:checked'
        );


    const submitButton =
        form.querySelector(
            ".pulse-poll__submit"
        );


    /*
    ----------------------------------------------
    CONFIRM WEEKLY VOTING STATUS
    ----------------------------------------------
    */

    try {

        const weeklyStatus =
            await getPresidentialApprovalParticipationStatus();


        if (
            weeklyStatus?.alreadyParticipated
        ) {

            lockApprovalForm(
                `You have already responded for ${weeklyStatus.votingPeriodLabel}. Voting reopens next Monday.`
            );


            return;

        }

    } catch (error) {

        console.error(
            "Presidential approval weekly status check failed:",
            error
        );


        showMessage(
            "Voting access could not be confirmed. Please try again.",
            "error"
        );


        return;

    }


    /*
    ----------------------------------------------
    RESPONSE REQUIRED
    ----------------------------------------------
    */

    if (
        !selectedInput
    ) {

        showMessage(
            "Please select one response.",
            "error"
        );


        return;

    }


    /*
    ----------------------------------------------
    SUBMIT
    ----------------------------------------------
    */

    setSubmittingState(
        submitButton,
        true
    );


    showMessage(
        "Saving your response...",
        "info"
    );


    try {

        await submitPresidentialApprovalResponse(
            selectedInput.value
        );


        markPresidentialApprovalSubmitted();


        lockApprovalForm(
            "Thank you. Your response has been recorded."
        );

    } catch (error) {

        console.error(
            "Presidential approval submission error:",
            error
        );


        if (
            error?.code ===
            "already-participated-this-week"
        ) {

            lockApprovalForm(
                "You have already responded this week. Voting reopens next Monday."
            );


            return;

        }


        setSubmittingState(
            submitButton,
            false
        );


        showMessage(
            "Your response could not be submitted. Please try again.",
            "error"
        );

    }

}


/*
==================================================
FORM STATE
==================================================
*/

function setSubmittingState(
    submitButton,
    isSubmitting
) {

    if (
        !submitButton
    ) {

        return;

    }


    submitButton.disabled =
        isSubmitting;


    submitButton.textContent =
        isSubmitting
            ? "Submitting..."
            : "Submit Response";

}


/*
==================================================
LOCK APPROVAL FORM
==================================================
*/

function lockApprovalForm(
    message
) {

    const form =
        document.getElementById(
            "presidentialApprovalForm"
        );


    if (
        !form
    ) {

        return;

    }


    form
        .querySelectorAll(
            'input[name="presidentialApproval"]'
        )
        .forEach(
            input => {

                input.disabled =
                    true;

            }
        );


    const submitButton =
        form.querySelector(
            ".pulse-poll__submit"
        );


    if (
        submitButton
    ) {

        submitButton.disabled =
            true;


        submitButton.textContent =
            "Response Submitted";

    }


    showMessage(
        message,
        "success"
    );

}


/*
==================================================
ERROR STATE
==================================================
*/

function renderApprovalError() {

    setText(
        "pulseResponseCount",
        "—"
    );


    setText(
        "pulseUpdatedText",
        "Results unavailable"
    );


    Object
        .values(
            resultElements
        )
        .forEach(
            elementMap => {

                setText(
                    elementMap.percentId,
                    "—"
                );


                setBarWidth(
                    elementMap.barId,
                    0
                );

            }
        );


    const submitButton =
        document.querySelector(
            ".pulse-poll__submit"
        );


    if (
        submitButton
    ) {

        submitButton.disabled =
            true;

    }


    showMessage(
        "Live voting is temporarily unavailable.",
        "error"
    );

}


/*
==================================================
MESSAGE HELPER
==================================================
*/

function showMessage(
    message,
    type
) {

    const messageElement =
        document.getElementById(
            "presidentialApprovalMessage"
        );


    if (
        !messageElement
    ) {

        return;

    }


    messageElement.textContent =
        message;


    messageElement.dataset.messageType =
        type;

}


/*
==================================================
DOM HELPERS
==================================================
*/

function setText(
    elementId,
    value
) {

    const element =
        document.getElementById(
            elementId
        );


    if (
        !element
    ) {

        return;

    }


    element.textContent =
        String(
            value
        );

}


/*
==================================================
BAR WIDTH
==================================================
*/

function setBarWidth(
    elementId,
    percentage
) {

    const element =
        document.getElementById(
            elementId
        );


    if (
        !element
    ) {

        return;

    }


    const safePercentage =
        Math.max(
            0,
            Math.min(
                100,
                Number(
                    percentage
                ) || 0
            )
        );


    element.style.width =
        `${safePercentage}%`;

}


/*
==================================================
FORMAT HELPERS
==================================================
*/

function formatNumber(
    value
) {

    const number =
        Number(
            value
        );


    if (
        !Number.isFinite(
            number
        )
    ) {

        return "0";

    }


    return number
        .toLocaleString();

}


/*
==================================================
TIME
==================================================
*/

function formatTime(
    date
) {

    if (
        !(date instanceof Date) ||
        Number.isNaN(
            date.getTime()
        )
    ) {

        return "live";

    }


    return date
        .toLocaleTimeString(
            undefined,
            {
                hour:
                    "numeric",

                minute:
                    "2-digit"
            }
        );

}


/*
==================================================
CLEANUP
==================================================
*/

export function destroyNationalPulseController() {

    if (
        typeof unsubscribePulseSummary ===
        "function"
    ) {

        unsubscribePulseSummary();

    }


    const form =
        document.getElementById(
            "presidentialApprovalForm"
        );


    if (
        form
    ) {

        form.removeEventListener(
            "submit",
            handleApprovalSubmit
        );

    }


    unsubscribePulseSummary =
        null;


    nationalPulseControllerInitialized =
        false;

}
